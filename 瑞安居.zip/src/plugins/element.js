import Vue from 'vue'
import { Button,Image,Card,Row,Col,Carousel,CarouselItem,Dropdown,DropdownItem,DropdownMenu,
    Breadcrumb,BreadcrumbItem,Input,Dialog,Form,FormItem
} from 'element-ui'

Vue.use(Button)
Vue.use(Image)
Vue.use(Card)
Vue.use(Row)
Vue.use(Col)
Vue.use(Carousel)
Vue.use(CarouselItem)
Vue.use(Dropdown)
Vue.use(DropdownItem)
Vue.use(DropdownMenu)
Vue.use(Breadcrumb)
Vue.use(BreadcrumbItem)
Vue.use(Input)
Vue.use(Dialog)
Vue.use(Form)
Vue.use(FormItem)
