let host = 'http://www.realtoraccess.com';
export default {
    // 经纪人信息
    AGENT_BYID: host + '/portal/agent',
    // 推荐房源
    AGENT_LISTINGS:host+'/portal/agent/listings',
    //
    AGENT_CHINESE_SERVICE:host+'/portal/chinese/service'

}