// let host = 'http://www.realtoraccess.com';
let host = '';
export default {
    //首页
    INDEX_COUNT: host + '/portal/count',//计数
    INDEX_AGENTS: host + '/portal/agents',//经纪人banner
    INDEX_LISTINGS: host + '/portal/listings',//推荐房源
    INDEX_CORPS: host + '/portal/corps',//公司动态
    INDEX_ARTICLES: host + '/portal/articles',//相关阅读

}